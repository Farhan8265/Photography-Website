<?php
session_start();
include 'userinfo.php'; // Include your existing connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($con, $_POST['user']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username' OR email='$username'";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            header("Location: user_page.php");
            exit();
        } else {
            echo "<script>alert('Invalid Username or Password. Please try again.'); window.location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid Username or Password. Please try again.'); window.location.href='login.php';</script>";
    }
} else {
    echo "Form submission method is not POST.";
}

mysqli_close($con);

if ($username === 'admin' && $password === 'password') {
    $_SESSION['user'] = $username;
    header("Location: login.php?login=success");
} else {
    header("Location: login.php?login=fail");
}
exit();
?>
