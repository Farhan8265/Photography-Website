<?php
session_start();
include 'userinfo.php'; // Include your existing connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($con, $_POST['user']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check if the email address already exists in the database
    $check_email = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($con, $check_email);

    if (mysqli_num_rows($result) > 0) {
        // If the email already exists, display an error message
        echo "<script>alert('User already exists with this email address. Please try with a different email.'); window.location.href='signup.php';</script>";
    } else {
        // If the email is unique, insert the new user details into the database
        $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        if (mysqli_query($con, $sql)) {
            echo "<script>alert('Signup Successful'); window.location.href='login.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($con);
        }
    }
}
mysqli_close($con);

header("Location: signup.php?signup=success");
exit();
?>
