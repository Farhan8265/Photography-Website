<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <title>PIXEL</title>
</head>
<body>

  <!-- For Top Navigation Bar -->  
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<a class="navbar-brand" href="index.php">
    P I X E L
    <img src="images/icon.jpg" alt="Logo" width="35" height="35" class="d-inline-block align-top">
</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php#services">Services</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="about.php">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php#contact">Contact</a>
            </li>      
        </ul>
        <form class="form-inline my-2 my-lg-0" action="https://www.google.com/searchbyimage" method="POST" target="_blank">
            <input class="form-control mr-sm-2" type="text" name="image_url" placeholder="Search for images" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="login.php">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="signup.php">Signup</a>
            </li>
        </ul>
    </div>
</nav>


<!-- For Sliding Pictures at the top of the page, below navigation bar -->
<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/1.jpg" alt="Slide 1" width="1100" height="500">
      <div class="carousel-caption">
        <h1><b>Capturing Moments That Tell You A Story</b></h1>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/2.jpg" alt="Slide 2" width="1100" height="500">
      <div class="carousel-caption">
        <h1>Transforming Ordinary Scenes Into Extraordinary Memories</h1>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/3.jpg" alt="Slide 3" width="1100" height="500">
      <div class="carousel-caption">
        <h1>Exploring The World, One Frame At A Time</h1>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<!-- Section for ABOUT ME -->
<section class="my-5">
<div class="py-5">
  <h2 class="text-center"><b>ABOUT ME</b></h2>
</div>

<div class="container-fluid">
<div class="row">
  <div class="col-lg-6 col-md-6 col-12">
    <img src="images/photographer.jpg" class="img-fluid aboutimg service-image">
  </div>
  <div class="col-lg-6 col-md-6 col-12">
    <h2 class="display-4">I Am A Photographer</h2>
    <p class="py-4" style="text-align: justify;">Photography, for me, is more than just a profession; it's a lifelong passion that allows me to freeze moments in time, capturing the raw emotions and intricate details that often go unnoticed. With each click, I strive to weave a story, evoke emotions, and ignite imaginations. With an unwavering passion for freezing time in the most exquisite frames, we delve into the artistry of photography, painting narratives with light and shadow.</p>
    <a href="about.php" class="btn btn-success">See More</a>
  </div>
</div>
</div>

</section>

<!-- Section For OUR SERVICES -->
<section id="services" class="my-5">
  <div class="py-5">
    <h2 class="text-center"><b>OUR SERVICES</b></h2>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12 service-card">
        <div class="card">
          <img class="card-img-top" src="images/5.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Nature Photography</h4>
            <a href="#" class="btn btn-primary">See Profile</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12 service-card">
        <div class="card">
          <img class="card-img-top" src="images/6.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Event Photography</h4>
            <a href="#" class="btn btn-primary">See Profile</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12 service-card">
        <div class="card">
          <img class="card-img-top" src="images/7.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Landscape Photography</h4>
            <a href="#" class="btn btn-primary">See Profile</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- Section For Gallary -->
<section class="my-5">
<div class="py-5">
  <h2 class="text-center"><b>OUR GALLARY</b></h2>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/11.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/12.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/13.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/14.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/15.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/16.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/17.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/18.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>

    <div class="col-lg-4 col-md-4 col-12">
      <img src="images/19.jpg" class="img-fluid pb-3 gallaryimg service-image">
    </div>
  </div>
</div>
</section>


<!-- Section for Contacting Us - User Info -->
<section id="contact" class="my-5 contact-section">
<div class="py-5">
  <h2 class="text-center"><b>CONTACT US</b></h2>
</div>

<div class="w-50 m-auto">
  <form action="userinfo.php" method="post">
    <div class="form-group">
      <label>User Name</label>
      <input type="text" name="user" placeholder="Enter username" autocomplete="off" class="form-control" required>
    </div>

    <div class="form-group">
      <label>Email ID</label>
      <input type="text" name="email" placeholder="Enter Email" autocomplete="off" class="form-control" required>
    </div>

    <div class="form-group">
      <label>Phone Number</label>
      <input type="text" name="mobile" placeholder="Enter Phone Number" autocomplete="off" class="form-control" required>
    </div>

    <div class="form-group">
      <label>Comment</label>
      <textarea class="form-control" name="comment">
      </textarea>
    </div>
    <button type="submit" class="btn btn-success">Send Message</button>

  </form>
</div>
</section>


    <!-- Contact Info Section -->
    <section class="info_section layout_padding2">
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-left">
                    <div class="info-logo">
                        <a class="navbar-brand" href="index.php">
                            <h4>P I X E L
                                <img src="images/icon.jpg" alt="Logo" width="40" height="40" class="d-inline-block align-top">
                            </h4>
                        </a>
                        <p>
                            It is a long established fact that a reader will be distracted by the readable content of a page when
                            looking at its layout. The point of
                        </p>
                    </div>
                </div>
                
                <div class="col-md-4 text-center">
                    <div class="info-contact">
                        <h4>CONTACT INFO</h4>
                        <div class="location">
                            <h6>Main Office Address:</h6>
                            <a href="">
                                <img src="images/location.png" alt="">
                                <span>Islamabad, Pakistan</span>
                            </a>
                        </div>
                        <div class="call">
                            <h6>Customer Service:</h6>
                            <a href="">
                                <img src="images/call.png" alt="">
                                <span>( +92 312 1395107 )</span>
                            </a>
                        </div>
                        <div class="call">
                            <a href="">
                                <img src="images/mail.png" alt="">
                                <span>pixel123@gmail.com</span>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 text-right">
                    <div class="discover">
                        <h4>DISCOVER</h4>
                            <a href="">Need Help?</a><br>
                            <a href="">How It Works?</a><br>
                            <a href="index.php">Contact Us</a><br>
                     
                        <div class="social-box">
                            <a href=""><img src="images/fb.png" alt=""></a>
                            <a href=""><img src="images/twitter.png" alt=""></a>
                            <a href=""><img src="images/insta.png" alt=""></a>
                            <a href=""><img src="images/linkedin.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



<!-- For Footer -->
<footer>
  <p class="p-3 bg-dark text-white text-center">@2024 All Rights Reserved by Pixel</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>