<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <title>User Page</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<a class="navbar-brand" href="index.php">
    P I X E L
    <img src="images/icon.jpg" alt="Logo" width="35" height="35" class="d-inline-block align-top">
</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php#services">Services</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="about.php">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php#contact">Contact</a>
            </li>      
        </ul>
        <form class="form-inline my-2 my-lg-0" action="https://www.google.com/searchbyimage" method="POST" target="_blank">
            <input class="form-control mr-sm-2" type="text" name="image_url" placeholder="Search for images" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <h1 class="mt-5">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    <p>Upload your best images to .</p>

    <!-- Display messages -->
    <?php
    if (isset($_SESSION['upload_success'])) {
        echo '<div class="alert alert-success">' . $_SESSION['upload_success'] . '</div>';
        unset($_SESSION['upload_success']);
    }
    if (isset($_SESSION['upload_error'])) {
        echo '<div class="alert alert-danger">' . $_SESSION['upload_error'] . '</div>';
        unset($_SESSION['upload_error']);
    }
    ?>

    <!-- Image upload form -->
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="fileToUpload">Select image to upload:</label>
            <input type="file" class="form-control-file" id="fileToUpload" name="fileToUpload">
        </div>
        <button type="submit" class="btn btn-primary" name="submit">Upload Image</button>
    </form>

    <!-- Display uploaded image -->
    <?php
    if (isset($_SESSION['uploaded_file_path'])) {
        echo '<div class="mt-3">';
        echo '<h3>Uploaded Image:</h3>';
        echo '<img src="' . htmlspecialchars($_SESSION['uploaded_file_path']) . '" class="img-fluid">';
        unset($_SESSION['uploaded_file_path']);
        echo '</div>';
    }
    ?>
</div>

<footer>
  <p class="p-3 bg-dark text-white text-center">@2024 All Rights Reserved by Pixel</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
